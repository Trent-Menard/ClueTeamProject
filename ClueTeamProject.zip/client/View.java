package client;

public enum View {
    CONNECT_TO_SERVER,
    INITIAL,
    LOGIN,
    CREATE_ACCOUNT,
    WAITING_ROOM,
    ACCUSATION_PANEL,
    PLAYER_TURN,
    GATHER_INTEL
}