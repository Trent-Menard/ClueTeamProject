package client;

public class GatherIntelData {
	private String player;
	
	public GatherIntelData(String player) {
		setPlayer(player);
	}
	public String getPlayer() {
		return this.player;
	}
	public void setPlayer(String player) {
		this.player = player;
	}
}
