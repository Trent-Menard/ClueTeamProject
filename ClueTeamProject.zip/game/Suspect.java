package game;

public class Suspect extends Card{

//    private final String suspectName;
    public Suspect(String name) {
        super(name);
//        this.suspectName = name;
    }

//    public String getSuspectName() {
//        return suspectName;
//    }
}