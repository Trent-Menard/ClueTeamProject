package game;

public class RoomCard {

}
